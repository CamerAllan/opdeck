import { CSSProperties } from "react";

export const card = {
  margin: "auto",
  width: 700
} as CSSProperties;
